f = open('helloworld.txt','w')
f.write("Hello World!!!")
f.close
