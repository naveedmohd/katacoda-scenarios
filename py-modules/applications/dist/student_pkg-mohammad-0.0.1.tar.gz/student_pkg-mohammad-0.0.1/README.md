# Student Package

This package is created to have all dependencies for student.
