names=input("Please enter names in quotes separated by commas: ")
for name in names:
    print("Hello  {}!".format(name))
